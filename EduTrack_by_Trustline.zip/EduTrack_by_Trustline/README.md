# EduTrack by Trustline

A multi-school management platform starter for Nigerian primary and secondary schools.

## Included
- Public landing, school registration, login and password-reset request pages
- Role-based portals: super admin, school admin, teacher, student and parent
- Student, teacher, class, attendance, results and fee management screens
- Express API with MongoDB/Mongoose models and tenant-aware authorization
- Demo seed data and demo login accounts
- Responsive CSS, light/dark mode, CSV export helper
- Paystack integration placeholders (never store card details)

## Requirements
- Node.js 20 LTS or newer
- MongoDB Atlas or local MongoDB
- VS Code and Chrome

## Run locally
1. Open the `backend` folder in VS Code terminal.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and fill in `MONGODB_URI` and a long random `JWT_SECRET`.
4. Run `npm run seed` to create demo data.
5. Run `npm run dev`.
6. Open `http://localhost:5000`.

The Express server serves the frontend from `../frontend`, so no separate frontend server is required.

## Demo accounts
After seeding:
- Platform owner: `owner@edutrack.demo` / `DemoPass123!`
- School administrator: `admin@greenfield.demo` / `DemoPass123!`
- Teacher: `teacher@greenfield.demo` / `DemoPass123!`
- Student: `student@greenfield.demo` / `DemoPass123!`
- Parent: `parent@greenfield.demo` / `DemoPass123!`

Change demo passwords and remove demo data before any real deployment.

## Important production checklist
This is a working foundation/MVP, not yet a certified school information system. Before onboarding real schools:
- Configure HTTPS, production secrets, backups, monitoring and rate limits.
- Add email/SMS provider credentials and verify password-reset flows.
- Complete payment webhook verification before accepting payments.
- Review Nigeria's applicable data-protection requirements and obtain school/parent consent.
- Add formal audit retention, data export/deletion workflows and disaster recovery.
- Conduct security testing, authorization tests and user acceptance testing.
- Configure a production-grade file storage provider; do not store uploads on ephemeral hosting disks.

## Project structure
- `frontend/` static HTML, CSS and browser JavaScript
- `backend/` Express API, Mongoose models, middleware, routes and seed script
