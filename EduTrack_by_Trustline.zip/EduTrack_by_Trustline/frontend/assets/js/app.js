const API = '/api';
const $ = (s, root=document) => root.querySelector(s);
const money = kobo => new Intl.NumberFormat('en-NG',{style:'currency',currency:'NGN',maximumFractionDigits:0}).format((kobo||0)/100);
const getToken = () => localStorage.getItem('edutrack_token');
async function api(path, options={}) {
  const headers = {'Content-Type':'application/json', ...(options.headers||{})};
  if (getToken()) headers.Authorization = `Bearer ${getToken()}`;
  const response = await fetch(`${API}${path}`, {...options, headers});
  const data = await response.json().catch(()=>({message:'Unexpected server response.'}));
  if (!response.ok) throw new Error(data.message || 'Request failed.');
  return data;
}
function showMessage(el, message, good=false) { if(el){el.textContent=message;el.className=`form-message ${good?'success':'error'}`;} }

const loginForm = $('#loginForm');
if (loginForm) {
  $('#fillDemo')?.addEventListener('click',()=>{loginForm.email.value='admin@greenfield.demo';loginForm.password.value='DemoPass123!';});
  loginForm.addEventListener('submit',async e=>{
    e.preventDefault(); const btn=loginForm.querySelector('button[type=submit]'); btn.disabled=true; btn.textContent='Signing in…';
    try { const result=await api('/auth/login',{method:'POST',body:JSON.stringify({email:loginForm.email.value,password:loginForm.password.value})});
      localStorage.setItem('edutrack_token',result.token); localStorage.setItem('edutrack_user',JSON.stringify(result.user)); location.href=roleHome(result.user.role);
    } catch(err){showMessage($('#formMessage'),err.message);} finally {btn.disabled=false;btn.textContent='Sign in →';}
  });
}
function roleHome(role) {
  return ({super_admin:'../super-admin/dashboard.html',school_admin:'../school-admin/dashboard.html',teacher:'../teacher/dashboard.html',student:'../student/dashboard.html',parent:'../parent/dashboard.html'})[role] || 'login.html';
}
const registerForm=$('#registerForm');
if(registerForm) registerForm.addEventListener('submit',async e=>{
  e.preventDefault(); const payload=Object.fromEntries(new FormData(registerForm).entries());
  try {const result=await api('/auth/register-school',{method:'POST',body:JSON.stringify(payload)});showMessage($('#formMessage'),`${result.message} Your school code is ${result.schoolCode}.`,true);registerForm.reset();}
  catch(err){showMessage($('#formMessage'),err.message);}
});
const forgotForm=$('#forgotForm');
if(forgotForm) forgotForm.addEventListener('submit',async e=>{e.preventDefault();try{const r=await api('/auth/forgot-password',{method:'POST',body:JSON.stringify({email:forgotForm.email.value})});showMessage($('#formMessage'),r.message,true);}catch(err){showMessage($('#formMessage'),err.message);}});

const shell=$('#appShell');
if(shell) initApp(shell);
async function initApp(root) {
  const user=JSON.parse(localStorage.getItem('edutrack_user')||'null');
  if(!getToken()||!user){location.href='../login.html';return;}
  const role=root.dataset.role, page=root.dataset.page;
  const links = role==='super_admin'
    ? [['dashboard','Overview'],['schools','Schools'],['subscriptions','Subscriptions'],['settings','Settings']]
    : role==='teacher' ? [['dashboard','Overview'],['attendance','Attendance'],['results','Results'],['timetable','Timetable']]
    : role==='student' ? [['dashboard','Overview'],['results','Results'],['timetable','Timetable']]
    : role==='parent' ? [['dashboard','Overview'],['children','My children'],['payments','Payments']]
    : [['dashboard','Overview'],['students','Students'],['teachers','Teachers'],['classes','Classes & subjects'],['attendance','Attendance'],['results','Examinations & results'],['fees','Fees & payments'],['reports','Reports'],['settings','Settings']];
  const prefix=role==='super_admin'?'../super-admin/':role==='school_admin'?'../school-admin/':`../${role.replace('_','-')}/`;
  root.innerHTML=`<aside class="sidebar"><a class="brand side-brand" href="../index.html"><span class="brand-mark">E</span><span>EduTrack <small>by Trustline</small></span></a><div class="side-label">WORKSPACE</div><nav>${links.map(([id,label])=>`<a class="${page===id?'active':''}" href="${prefix}${id}.html"><span class="nav-dot"></span>${label}</a>`).join('')}</nav><div class="sidebar-bottom"><div class="profile-mini"><div class="avatar">${user.name?.[0]||'U'}</div><div><b>${escapeHtml(user.name)}</b><small>${role.replace('_',' ')}</small></div></div><button id="logoutBtn" class="logout">↪ Sign out</button></div></aside><main class="main-area"><header class="topbar"><div><span class="eyebrow">EDUTRACK WORKSPACE</span><h1>${pageTitle(page)}</h1></div><div class="top-actions"><button id="themeToggle" class="icon-btn" aria-label="Toggle theme">◐</button><div class="avatar">${user.name?.[0]||'U'}</div></div></header><section id="pageContent" class="page-content"><div class="loading">Loading your workspace…</div></section></main>`;
  $('#logoutBtn').onclick=()=>{localStorage.removeItem('edutrack_token');localStorage.removeItem('edutrack_user');location.href='../login.html';};
  $('#themeToggle').onclick=()=>{document.body.classList.toggle('dark');localStorage.setItem('edutrack_theme',document.body.classList.contains('dark')?'dark':'light');};
  if(localStorage.getItem('edutrack_theme')==='dark')document.body.classList.add('dark');
  try { const data=await api('/data/overview'); renderPage(page,role,data,user); }
  catch(err){$('#pageContent').innerHTML=`<div class="notice error">${escapeHtml(err.message)} <a href="../login.html">Sign in again</a></div>`;}
}
function pageTitle(p){return ({dashboard:'Overview',students:'Students',teachers:'Teachers',classes:'Classes & subjects',attendance:'Attendance',results:'Examinations & results',fees:'Fees & payments',reports:'Reports',settings:'Settings',schools:'Registered schools',subscriptions:'Subscriptions',timetable:'Timetable',children:'My children',payments:'Payments'})[p]||'Workspace';}
function escapeHtml(v=''){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
async function renderPage(page,role,stats,user){
 const target=$('#pageContent');
 const statCards=role==='super_admin'?[['Schools',stats.schools,'Registered'],['Pending approvals',stats.pendingSchools,'Needs review']]:[['Students',stats.students,'Student records'],['Teachers',stats.teachers,'Teaching staff'],['Classes',stats.classes,'Active classes'],['Fees collected',money(stats.feesCollectedKobo),'Recorded payments']];
 if(page==='dashboard'){
  target.innerHTML=`<div class="welcome-row"><div><h2>Good day, ${escapeHtml(user.name.split(' ')[0])} 👋</h2><p class="muted">Here's an overview of your ${role==='super_admin'?'EduTrack platform':'school'}.</p></div><span class="status-pill">● System operational</span></div><div class="stat-grid">${statCards.map(([l,v,s])=>`<article class="stat-card"><small>${l}</small><strong>${v}</strong><span>${s}</span></article>`).join('')}</div><div class="content-grid"><article class="panel"><div class="panel-head"><div><h3>Quick actions</h3><p class="muted">Common tasks for your workspace.</p></div></div><div class="quick-actions">${(role==='school_admin'?[['＋','Add student','students.html'],['＋','Add teacher','teachers.html'],['▦','Take attendance','attendance.html'],['₦','Record payment','fees.html']]:[['▤','View records','#'],['◷','Recent activity','#']]).map(x=>`<a href="${x[2]}"><b>${x[0]}</b><span>${x[1]}</span><i>→</i></a>`).join('')}</div></article><article class="panel"><h3>Getting started</h3><p class="muted">Complete these steps to set up your school workspace.</p><ul class="check-list"><li>Review your school profile</li><li>Add classes and subjects</li><li>Register students and teachers</li><li>Set up your academic session</li></ul></article></div>`;
 } else if(page==='students') await renderStudents(target);
 else if(page==='teachers') await renderTeachers(target);
 else if(page==='classes') await renderClasses(target);
 else if(page==='attendance') await renderAttendance(target);
 else if(page==='results') await renderResults(target);
 else if(page==='fees'||page==='payments') await renderPayments(target);
 else if(page==='schools') await renderSchools(target);
 else if(page==='reports') target.innerHTML=`<div class="panel"><h3>School reports</h3><p class="muted">Export available student records as CSV.</p><button class="btn btn-primary" id="exportStudents">Export students CSV</button></div>`;
 else target.innerHTML=`<div class="panel"><h3>${pageTitle(page)}</h3><p class="muted">This workspace section is ready for configuration. More controls will be added in the next development iteration.</p></div>`;
 $('#exportStudents')?.addEventListener('click',async()=>{const rows=await api('/data/students');downloadCSV('edutrack-students.csv',rows);});
}
function table(headers,rows){return `<div class="table-wrap"><table><thead><tr>${headers.map(h=>`<th>${h}</th>`).join('')}</tr></thead><tbody>${rows.length?rows.join(''):`<tr><td colspan="${headers.length}" class="empty">No records yet.</td></tr>`}</tbody></table></div>`;}
async function renderStudents(el){
 const rows=await api('/data/students');
 el.innerHTML=`<div class="page-toolbar"><div><h2>Student directory</h2><p class="muted">Maintain accurate student admission records.</p></div><button class="btn btn-primary" id="addStudent">＋ Add student</button></div><div class="panel">${table(['Admission no.','Student name','Class','Gender','Status'],rows.map(s=>`<tr><td>${escapeHtml(s.admissionNo)}</td><td><b>${escapeHtml(s.firstName+' '+s.lastName)}</b></td><td>${escapeHtml(s.className||'—')}</td><td>${escapeHtml(s.gender||'—')}</td><td><span class="status-pill">${escapeHtml(s.status)}</span></td></tr>`))}</div><div id="modalHost"></div>`;
 $('#addStudent').onclick=()=>openForm('Add student',[['admissionNo','Admission number'],['firstName','First name'],['lastName','Last name'],['className','Class'],['guardianName','Guardian name'],['guardianPhone','Guardian phone']],async data=>{await api('/data/students',{method:'POST',body:JSON.stringify(data)});await renderStudents(el);});
}
async function renderTeachers(el){
 const rows=await api('/data/teachers');
 el.innerHTML=`<div class="page-toolbar"><div><h2>Teaching staff</h2><p class="muted">Manage staff profiles and assignments.</p></div><button class="btn btn-primary" id="addTeacher">＋ Add teacher</button></div><div class="panel">${table(['Staff no.','Name','Email','Phone','Status'],rows.map(t=>`<tr><td>${escapeHtml(t.staffNo||'—')}</td><td><b>${escapeHtml(t.name)}</b></td><td>${escapeHtml(t.email||'—')}</td><td>${escapeHtml(t.phone||'—')}</td><td>${escapeHtml(t.status)}</td></tr>`))}</div><div id="modalHost"></div>`;
 $('#addTeacher').onclick=()=>openForm('Add teacher',[['staffNo','Staff number'],['name','Full name'],['email','Email'],['phone','Phone'],['subjects','Subjects (comma separated)'],['classes','Classes (comma separated)']],async d=>{d.subjects=(d.subjects||'').split(',').map(x=>x.trim()).filter(Boolean);d.classes=(d.classes||'').split(',').map(x=>x.trim()).filter(Boolean);await api('/data/teachers',{method:'POST',body:JSON.stringify(d)});await renderTeachers(el);});
}
async function renderClasses(el){
 const rows=await api('/data/classes');
 el.innerHTML=`<div class="page-toolbar"><div><h2>Classes & arms</h2><p class="muted">Organise your school's learning groups.</p></div><button class="btn btn-primary" id="addClass">＋ Add class</button></div><div class="panel">${table(['Class','Arm','Level','Class teacher','Capacity'],rows.map(c=>`<tr><td><b>${escapeHtml(c.name)}</b></td><td>${escapeHtml(c.arm)}</td><td>${escapeHtml(c.level)}</td><td>${escapeHtml(c.classTeacher||'—')}</td><td>${c.capacity}</td></tr>`))}</div><div id="modalHost"></div>`;
 $('#addClass').onclick=()=>openForm('Add class',[['name','Class name'],['arm','Arm'],['level','Level'],['classTeacher','Class teacher'],['capacity','Capacity']],async d=>{d.capacity=Number(d.capacity||40);await api('/data/classes',{method:'POST',body:JSON.stringify(d)});await renderClasses(el);});
}
async function renderAttendance(el){
 const [rows,students]=await Promise.all([api('/data/attendance'),api('/data/students')]);
 el.innerHTML=`<div class="page-toolbar"><div><h2>Attendance register</h2><p class="muted">Record daily student attendance.</p></div><button class="btn btn-primary" id="recordAttendance">＋ Record attendance</button></div><div class="panel">${table(['Date','Student','Class','Status'],rows.map(a=>`<tr><td>${new Date(a.date).toLocaleDateString()}</td><td>${escapeHtml(a.student?.firstName||'')} ${escapeHtml(a.student?.lastName||'')}</td><td>${escapeHtml(a.className||'—')}</td><td><span class="status-pill">${escapeHtml(a.status)}</span></td></tr>`))}</div><div id="modalHost"></div>`;
 $('#recordAttendance').onclick=()=>openForm('Record attendance',[['student','Student ID (copy from student directory)'],['date','Date (YYYY-MM-DD)'],['className','Class'],['status','Status: present / absent / late / excused']],async d=>{await api('/data/attendance',{method:'POST',body:JSON.stringify(d)});await renderAttendance(el);});
}
async function renderResults(el){
 const rows=await api('/data/results');
 el.innerHTML=`<div class="page-toolbar"><div><h2>Examinations & results</h2><p class="muted">Record continuous assessment and examination scores (100 total).</p></div><button class="btn btn-primary" id="addResult">＋ Enter result</button></div><div class="panel">${table(['Student','Subject','Session','Term','CA / 40','Exam / 60','Total','Grade'],rows.map(r=>`<tr><td>${escapeHtml(r.student?.firstName||'')} ${escapeHtml(r.student?.lastName||'')}</td><td>${escapeHtml(r.subject)}</td><td>${escapeHtml(r.session)}</td><td>${escapeHtml(r.term)}</td><td>${r.caScore}</td><td>${r.examScore}</td><td><b>${r.total}</b></td><td><span class="status-pill">${r.grade}</span></td></tr>`))}</div><div id="modalHost"></div>`;
 $('#addResult').onclick=()=>openForm('Enter result',[['student','Student ID'],['subject','Subject'],['session','Academic session'],['term','Term'],['className','Class'],['caScore','CA score (0–40)'],['examScore','Exam score (0–60)']],async d=>{d.caScore=Number(d.caScore);d.examScore=Number(d.examScore);await api('/data/results',{method:'POST',body:JSON.stringify(d)});await renderResults(el);});
}
async function renderPayments(el){
 const rows=await api('/data/payments');
 el.innerHTML=`<div class="page-toolbar"><div><h2>Fees & payments</h2><p class="muted">Review recorded school fee payments.</p></div><button class="btn btn-primary" id="addPayment">＋ Record payment</button></div><div class="panel">${table(['Reference','Description','Amount','Status','Date'],rows.map(p=>`<tr><td>${escapeHtml(p.reference)}</td><td>${escapeHtml(p.description||'—')}</td><td>${money(p.amountKobo)}</td><td><span class="status-pill">${escapeHtml(p.status)}</span></td><td>${p.paidAt?new Date(p.paidAt).toLocaleDateString():'—'}</td></tr>`))}</div><p class="muted small-note">Manual records are for administrative reconciliation. Online Paystack collection requires verified server-side webhooks before production use.</p><div id="modalHost"></div>`;
 $('#addPayment').onclick=()=>openForm('Record payment',[['amountNaira','Amount in naira'],['description','Description'],['term','Term'],['session','Academic session']],async d=>{d.amountNaira=Number(d.amountNaira);await api('/data/payments/manual',{method:'POST',body:JSON.stringify(d)});await renderPayments(el);});
}
async function renderSchools(el){
 const rows=await api('/data/schools');
 el.innerHTML=`<div class="page-toolbar"><div><h2>Registered schools</h2><p class="muted">Review and manage platform registrations.</p></div></div><div class="panel">${table(['School','Code','Email','Type','Status','Action'],rows.map(s=>`<tr><td><b>${escapeHtml(s.name)}</b></td><td>${escapeHtml(s.code)}</td><td>${escapeHtml(s.email)}</td><td>${escapeHtml(s.schoolType)}</td><td>${escapeHtml(s.status)}</td><td><button class="text-button" data-school="${s._id}" data-status="${s.status==='active'?'suspended':'active'}">${s.status==='active'?'Suspend':'Approve / activate'}</button></td></tr>`))}</div>`;
 el.querySelectorAll('[data-school]').forEach(b=>b.onclick=async()=>{await api(`/data/schools/${b.dataset.school}/status`,{method:'PATCH',body:JSON.stringify({status:b.dataset.status})});await renderSchools(el);});
}
function openForm(title,fields,onSave){
 const host=$('#modalHost');host.innerHTML=`<div class="modal-backdrop"><form class="modal-card" id="dataForm"><button type="button" class="modal-close" id="closeModal">×</button><h3>${title}</h3>${fields.map(([name,label])=>`<label>${label}<input name="${name}" required></label>`).join('')}<p id="modalError" class="form-message"></p><button class="btn btn-primary full" type="submit">Save record</button></form></div>`;
 $('#closeModal').onclick=()=>host.innerHTML='';
 $('#dataForm').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget).entries());try{await onSave(data);host.innerHTML='';}catch(err){showMessage($('#modalError'),err.message);}};
}
function downloadCSV(name,rows){
 if(!rows.length)return;const keys=Object.keys(rows[0]);const csv=[keys.join(','),...rows.map(r=>keys.map(k=>`"${String(r[k]??'').replace(/"/g,'""')}"`).join(','))].join('\\n');
 const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([csv],{type:'text/csv'}));a.download=name;a.click();URL.revokeObjectURL(a.href);
}
