const { AuditLog } = require('../models');
async function audit(req, action, entity, entityId, details = {}) {
  try {
    await AuditLog.create({ school: req.user.school || null, actor: req.user._id, action, entity, entityId: String(entityId || ''), details });
  } catch (e) { console.error('Audit log failed:', e.message); }
}
module.exports = audit;
