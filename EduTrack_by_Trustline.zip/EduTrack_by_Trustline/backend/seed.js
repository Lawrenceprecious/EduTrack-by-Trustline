require('dotenv').config();
const bcrypt = require('bcryptjs');
const connectDB = require('./config/db');
const { School, User, Student, Teacher, SchoolClass, Attendance, Result, Payment } = require('./models');

async function run() {
  await connectDB();
  await Promise.all([School.deleteMany({code:'GREENFIELD-DEMO'}), User.deleteMany({email:/@(?:edutrack|greenfield)\.demo$/}), Student.deleteMany({admissionNo:/^GF-DEMO-/})]);
  const school = await School.create({name:'Greenfield International School',code:'GREENFIELD-DEMO',email:'office@greenfield.demo',phone:'+234 800 000 0000',address:'Port Harcourt, Rivers State',schoolType:'both',status:'active',plan:'professional'});
  const hash = await bcrypt.hash('DemoPass123!',12);
  const users = [
    {name:'EduTrack Platform Owner',email:'owner@edutrack.demo',role:'super_admin',school:null},
    {name:'School Administrator',email:'admin@greenfield.demo',role:'school_admin',school:school._id},
    {name:'Ada Teacher',email:'teacher@greenfield.demo',role:'teacher',school:school._id},
    {name:'Daniel Student',email:'student@greenfield.demo',role:'student',school:school._id},
    {name:'Parent Account',email:'parent@greenfield.demo',role:'parent',school:school._id}
  ];
  await User.insertMany(users.map(u=>({...u,passwordHash:hash})));
  const classes = await SchoolClass.insertMany([
    {school:school._id,name:'Primary 5',arm:'A',level:'primary',capacity:35},
    {school:school._id,name:'JSS 2',arm:'A',level:'junior_secondary',capacity:40},
    {school:school._id,name:'SSS 1',arm:'B',level:'senior_secondary',capacity:40}
  ]);
  const students = await Student.insertMany([
    {school:school._id,admissionNo:'GF-DEMO-001',firstName:'Daniel',lastName:'Okafor',gender:'male',className:'Primary 5',guardianName:'Mrs Okafor',guardianPhone:'+234 800 111 2222'},
    {school:school._id,admissionNo:'GF-DEMO-002',firstName:'Amara',lastName:'Eze',gender:'female',className:'JSS 2',guardianName:'Mr Eze',guardianPhone:'+234 800 222 3333'},
    {school:school._id,admissionNo:'GF-DEMO-003',firstName:'David',lastName:'Bassey',gender:'male',className:'SSS 1',guardianName:'Mrs Bassey',guardianPhone:'+234 800 333 4444'}
  ]);
  await Teacher.create({school:school._id,staffNo:'T-001',name:'Ada Teacher',email:'teacher@greenfield.demo',subjects:['Mathematics','Basic Science'],classes:['Primary 5','JSS 2']});
  await Attendance.create({school:school._id,student:students[0]._id,date:new Date(),className:'Primary 5',status:'present'});
  await Result.create({school:school._id,student:students[0]._id,session:'2026/2027',term:'First Term',className:'Primary 5',subject:'Mathematics',caScore:32,examScore:51,total:83,grade:'A',remark:'Excellent'});
  await Payment.create({school:school._id,student:students[0]._id,reference:'DEMO-FEE-001',description:'First Term Tuition',amountKobo:7500000,status:'paid',paidAt:new Date(),term:'First Term',session:'2026/2027'});
  console.log('Demo data created. Password for all demo users: DemoPass123!');
  process.exit(0);
}
run().catch(e=>{console.error(e);process.exit(1);});
