const mongoose = require('mongoose');
const { Schema, model } = mongoose;

const schoolSchema = new Schema({
  name: { type: String, required: true, trim: true },
  code: { type: String, required: true, unique: true, uppercase: true },
  email: { type: String, required: true, lowercase: true },
  phone: String, address: String,
  schoolType: { type: String, enum: ['primary','secondary','both'], default: 'both' },
  status: { type: String, enum: ['pending','active','suspended'], default: 'pending' },
  plan: { type: String, enum: ['starter','professional','enterprise'], default: 'starter' },
  logoUrl: String
}, { timestamps: true });

const userSchema = new Schema({
  school: { type: Schema.Types.ObjectId, ref: 'School', default: null, index: true },
  name: { type: String, required: true, trim: true },
  email: { type: String, required: true, lowercase: true, unique: true, index: true },
  passwordHash: { type: String, required: true, select: false },
  role: { type: String, enum: ['super_admin','school_admin','teacher','student','parent'], required: true },
  linkedStudentIds: [{ type: Schema.Types.ObjectId, ref: 'Student' }],
  isActive: { type: Boolean, default: true },
  lastLoginAt: Date
}, { timestamps: true });

const studentSchema = new Schema({
  school: { type: Schema.Types.ObjectId, ref: 'School', required: true, index: true },
  admissionNo: { type: String, required: true },
  firstName: { type: String, required: true }, lastName: { type: String, required: true },
  gender: { type: String, enum: ['male','female','other'], default: 'other' },
  dateOfBirth: Date, className: String, arm: String, guardianName: String, guardianPhone: String,
  status: { type: String, enum: ['active','graduated','withdrawn'], default: 'active' }
}, { timestamps: true });
studentSchema.index({ school: 1, admissionNo: 1 }, { unique: true });

const teacherSchema = new Schema({
  school: { type: Schema.Types.ObjectId, ref: 'School', required: true, index: true },
  staffNo: String, name: { type: String, required: true }, email: String, phone: String,
  subjects: [String], classes: [String], status: { type: String, default: 'active' }
}, { timestamps: true });

const classSchema = new Schema({
  school: { type: Schema.Types.ObjectId, ref: 'School', required: true, index: true },
  name: { type: String, required: true }, arm: { type: String, default: 'A' },
  level: { type: String, enum: ['primary','junior_secondary','senior_secondary'], default: 'primary' },
  classTeacher: String, capacity: { type: Number, default: 40 }
}, { timestamps: true });

const attendanceSchema = new Schema({
  school: { type: Schema.Types.ObjectId, ref: 'School', required: true, index: true },
  student: { type: Schema.Types.ObjectId, ref: 'Student', required: true },
  date: { type: Date, required: true }, className: String,
  status: { type: String, enum: ['present','absent','late','excused'], required: true },
  recordedBy: { type: Schema.Types.ObjectId, ref: 'User' }
}, { timestamps: true });
attendanceSchema.index({ school: 1, student: 1, date: 1 }, { unique: true });

const resultSchema = new Schema({
  school: { type: Schema.Types.ObjectId, ref: 'School', required: true, index: true },
  student: { type: Schema.Types.ObjectId, ref: 'Student', required: true },
  session: String, term: String, className: String, subject: String,
  caScore: { type: Number, min: 0, max: 40, default: 0 },
  examScore: { type: Number, min: 0, max: 60, default: 0 },
  total: Number, grade: String, remark: String,
  submittedBy: { type: Schema.Types.ObjectId, ref: 'User' },
  approved: { type: Boolean, default: false }
}, { timestamps: true });

const paymentSchema = new Schema({
  school: { type: Schema.Types.ObjectId, ref: 'School', required: true, index: true },
  student: { type: Schema.Types.ObjectId, ref: 'Student' },
  reference: { type: String, required: true, unique: true },
  description: String, amountKobo: { type: Number, required: true },
  status: { type: String, enum: ['pending','paid','failed'], default: 'pending' },
  paidAt: Date, term: String, session: String
}, { timestamps: true });

const auditSchema = new Schema({
  school: { type: Schema.Types.ObjectId, ref: 'School', default: null, index: true },
  actor: { type: Schema.Types.ObjectId, ref: 'User' },
  action: String, entity: String, entityId: String, details: Schema.Types.Mixed
}, { timestamps: true });

module.exports = {
  School: model('School', schoolSchema), User: model('User', userSchema),
  Student: model('Student', studentSchema), Teacher: model('Teacher', teacherSchema),
  SchoolClass: model('SchoolClass', classSchema), Attendance: model('Attendance', attendanceSchema),
  Result: model('Result', resultSchema), Payment: model('Payment', paymentSchema),
  AuditLog: model('AuditLog', auditSchema)
};
