const router = require('express').Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { User, School } = require('../models');
const { protect } = require('../middleware/auth');

function tokenFor(user) {
  return jwt.sign({ sub: user._id, role: user.role, school: user.school }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRES_IN || '1d' });
}
function publicUser(user) {
  return { id: user._id, name: user.name, email: user.email, role: user.role, schoolId: user.school };
}
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ message: 'Email and password are required.' });
  const user = await User.findOne({ email: String(email).toLowerCase() }).select('+passwordHash');
  if (!user || !user.isActive || !(await bcrypt.compare(password, user.passwordHash)))
    return res.status(401).json({ message: 'Invalid email or password.' });
  user.lastLoginAt = new Date(); await user.save();
  res.json({ token: tokenFor(user), user: publicUser(user) });
});
router.post('/register-school', async (req, res) => {
  const { schoolName, schoolEmail, adminName, adminEmail, password, phone, schoolType } = req.body;
  if (![schoolName, schoolEmail, adminName, adminEmail, password].every(Boolean))
    return res.status(400).json({ message: 'Please complete all required fields.' });
  if (String(password).length < 10) return res.status(400).json({ message: 'Use a password of at least 10 characters.' });
  const exists = await User.findOne({ email: String(adminEmail).toLowerCase() });
  if (exists) return res.status(409).json({ message: 'This administrator email is already registered.' });
  const code = ('EDU' + Math.random().toString(36).slice(2, 8)).toUpperCase();
  const school = await School.create({ name: schoolName, email: schoolEmail, code, phone, schoolType: schoolType || 'both', status: 'pending' });
  const passwordHash = await bcrypt.hash(password, 12);
  const user = await User.create({ school: school._id, name: adminName, email: adminEmail, passwordHash, role: 'school_admin' });
  res.status(201).json({ message: 'School registration submitted. Your account awaits platform approval.', schoolCode: school.code, user: publicUser(user) });
});
router.get('/me', protect, async (req, res) => res.json({ user: publicUser(req.user), school: req.school }));
router.post('/forgot-password', async (req, res) => {
  // Deliberately generic response to avoid revealing whether an email is registered.
  res.json({ message: 'If the account exists, password-reset instructions will be sent when email delivery is configured.' });
});
module.exports = router;
