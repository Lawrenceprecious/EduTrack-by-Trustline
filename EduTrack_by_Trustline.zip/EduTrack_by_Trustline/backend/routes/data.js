const router = require('express').Router();
const { Student, Teacher, SchoolClass, Attendance, Result, Payment, School, User } = require('../models');
const { protect, allow, requireActiveSchool } = require('../middleware/auth');
const audit = require('../utils/audit');
router.use(protect, requireActiveSchool);

const schoolFilter = req => req.user.role === 'super_admin' ? {} : { school: req.user.school };
router.get('/overview', async (req, res) => {
  const filter = schoolFilter(req);
  const [schools, students, teachers, classes, payments, pending] = await Promise.all([
    req.user.role === 'super_admin' ? School.countDocuments() : Promise.resolve(0),
    Student.countDocuments(filter), Teacher.countDocuments(filter), SchoolClass.countDocuments(filter),
    Payment.aggregate([{ $match: { ...filter, status: 'paid' } }, { $group: { _id: null, total: { $sum: '$amountKobo' } } }]),
    req.user.role === 'super_admin' ? School.countDocuments({ status: 'pending' }) : Promise.resolve(0)
  ]);
  res.json({ schools, students, teachers, classes, feesCollectedKobo: payments[0]?.total || 0, pendingSchools: pending });
});
router.get('/schools', allow('super_admin'), async (req,res) => res.json(await School.find().sort({createdAt:-1})));
router.patch('/schools/:id/status', allow('super_admin'), async (req,res) => {
  if (!['active','suspended','pending'].includes(req.body.status)) return res.status(400).json({message:'Invalid status'});
  const school = await School.findByIdAndUpdate(req.params.id, {status:req.body.status}, {new:true});
  if (!school) return res.status(404).json({message:'School not found'});
  await audit(req,'update','School',school._id,{status:school.status}); res.json(school);
});
router.get('/students', allow('super_admin','school_admin','teacher'), async (req,res) => {
  const query = schoolFilter(req);
  const data = await Student.find(query).sort({createdAt:-1}).limit(500);
  res.json(data);
});
router.post('/students', allow('school_admin'), async (req,res) => {
  const { admissionNo, firstName, lastName } = req.body;
  if (!admissionNo || !firstName || !lastName) return res.status(400).json({message:'Admission number, first name and last name are required.'});
  try {
    const student = await Student.create({...req.body, school:req.user.school});
    await audit(req,'create','Student',student._id,{admissionNo});
    res.status(201).json(student);
  } catch(e) { res.status(400).json({message:e.code===11000?'Admission number already exists.':e.message}); }
});
router.get('/teachers', allow('super_admin','school_admin'), async (req,res) => res.json(await Teacher.find(schoolFilter(req)).sort({name:1})));
router.post('/teachers', allow('school_admin'), async (req,res) => {
  if (!req.body.name) return res.status(400).json({message:'Teacher name is required.'});
  const teacher = await Teacher.create({...req.body,school:req.user.school});
  await audit(req,'create','Teacher',teacher._id); res.status(201).json(teacher);
});
router.get('/classes', allow('super_admin','school_admin','teacher','student'), async (req,res) => res.json(await SchoolClass.find(schoolFilter(req)).sort({name:1})));
router.post('/classes', allow('school_admin'), async (req,res) => {
  if (!req.body.name) return res.status(400).json({message:'Class name is required.'});
  const item = await SchoolClass.create({...req.body,school:req.user.school});
  await audit(req,'create','Class',item._id); res.status(201).json(item);
});
router.get('/attendance', allow('school_admin','teacher'), async (req,res) => {
  const rows = await Attendance.find(schoolFilter(req)).populate('student','firstName lastName admissionNo').sort({date:-1}).limit(500);
  res.json(rows);
});
router.post('/attendance', allow('school_admin','teacher'), async (req,res) => {
  const { student, date, status, className } = req.body;
  if (!student || !date || !['present','absent','late','excused'].includes(status)) return res.status(400).json({message:'Student, date and valid status are required.'});
  const belongs = await Student.findOne({_id:student,school:req.user.school});
  if (!belongs) return res.status(404).json({message:'Student not found in this school.'});
  const row = await Attendance.findOneAndUpdate({school:req.user.school,student,date:new Date(date)}, {school:req.user.school,student,date:new Date(date),status,className,recordedBy:req.user._id}, {new:true,upsert:true,setDefaultsOnInsert:true});
  await audit(req,'record','Attendance',row._id,{status}); res.status(201).json(row);
});
router.get('/results', allow('school_admin','teacher','student','parent'), async (req,res) => res.json(await Result.find(schoolFilter(req)).populate('student','firstName lastName admissionNo').sort({createdAt:-1}).limit(500)));
router.post('/results', allow('school_admin','teacher'), async (req,res) => {
  const {student,subject,caScore=0,examScore=0,session,term,className} = req.body;
  if (!student || !subject || !session || !term) return res.status(400).json({message:'Student, subject, session and term are required.'});
  const studentDoc = await Student.findOne({_id:student,school:req.user.school});
  if (!studentDoc) return res.status(404).json({message:'Student not found in this school.'});
  const ca=Number(caScore), exam=Number(examScore);
  if (!Number.isFinite(ca)||!Number.isFinite(exam)||ca<0||ca>40||exam<0||exam>60) return res.status(400).json({message:'CA must be 0–40 and exam must be 0–60.'});
  const total=ca+exam, grade=total>=70?'A':total>=60?'B':total>=50?'C':total>=45?'D':total>=40?'E':'F';
  const result=await Result.create({school:req.user.school,student,subject,caScore:ca,examScore:exam,total,grade,session,term,className,submittedBy:req.user._id,approved:req.user.role==='school_admin'});
  await audit(req,'create','Result',result._id,{total,grade}); res.status(201).json(result);
});
router.get('/payments', allow('school_admin','parent'), async (req,res) => res.json(await Payment.find(schoolFilter(req)).populate('student','firstName lastName admissionNo').sort({createdAt:-1}).limit(500)));
router.post('/payments/manual', allow('school_admin'), async (req,res) => {
  const amount = Number(req.body.amountNaira);
  if (!Number.isFinite(amount)||amount<=0) return res.status(400).json({message:'Enter a valid amount.'});
  const reference='MAN-'+Date.now()+'-'+Math.random().toString(36).slice(2,7);
  const payment=await Payment.create({school:req.user.school,student:req.body.student||undefined,reference,description:req.body.description||'School fee payment',amountKobo:Math.round(amount*100),status:'paid',paidAt:new Date(),term:req.body.term,session:req.body.session});
  await audit(req,'record','Payment',payment._id,{amountNaira:amount}); res.status(201).json(payment);
});
module.exports = router;
