const jwt = require('jsonwebtoken');
const { User, School } = require('../models');

async function protect(req, res, next) {
  try {
    const header = req.headers.authorization || '';
    const token = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ message: 'Please log in to continue.' });
    const payload = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(payload.sub).select('+passwordHash');
    if (!user || !user.isActive) return res.status(401).json({ message: 'Account unavailable.' });
    req.user = user;
    req.school = user.school ? await School.findById(user.school) : null;
    next();
  } catch (error) {
    return res.status(401).json({ message: 'Session expired. Please log in again.' });
  }
}
function allow(...roles) {
  return (req, res, next) => roles.includes(req.user.role)
    ? next() : res.status(403).json({ message: 'You do not have permission to perform this action.' });
}
function requireActiveSchool(req, res, next) {
  if (req.user.role === 'super_admin') return next();
  if (!req.school || req.school.status !== 'active')
    return res.status(403).json({ message: 'This school account is not active yet.' });
  next();
}
module.exports = { protect, allow, requireActiveSchool };
