require('dotenv').config();
const express = require('express');
const path = require('path');
const helmet = require('helmet');
const cors = require('cors');
const rateLimit = require('express-rate-limit');
const morgan = require('morgan');
const connectDB = require('./config/db');
const authRoutes = require('./routes/auth');
const dataRoutes = require('./routes/data');

const app = express();
app.use(helmet({ contentSecurityPolicy: false }));
app.use(cors({ origin: process.env.CLIENT_URL || true }));
app.use(express.json({ limit: '1mb' }));
app.use(morgan('dev'));
app.use('/api/', rateLimit({ windowMs: 15 * 60 * 1000, limit: 300, standardHeaders: 'draft-7', legacyHeaders: false }));
app.get('/api/health', (req,res)=>res.json({status:'ok',service:'EduTrack API'}));
app.use('/api/auth', authRoutes);
app.use('/api/data', dataRoutes);
app.use(express.static(path.join(__dirname, '../frontend')));
app.get('*', (req,res)=>res.sendFile(path.join(__dirname,'../frontend/index.html')));
app.use((err,req,res,next)=>{ console.error(err); res.status(500).json({message:'Something went wrong. Please try again.'}); });

const PORT = process.env.PORT || 5000;
connectDB().then(()=>app.listen(PORT,()=>console.log(`EduTrack running at http://localhost:${PORT}`)))
  .catch(err=>{ console.error('Startup failed:',err.message); process.exit(1); });
